# Steel-Path-Void-Cascade-alarm 0.2.0
Same thing as before... Tracks Steel Path Void Cascade omnia fissures in Warframe. Automatically checks every 5 minutes, with a manual force check option.

BUT NOW WITH MORE!

Cleaned up the UI (MAJORLY)
Added a GitHub update prompt integrated into the startup thread that runs independently of the main UI loop.
MADE a GitHub for the project and uploaded the older version.
Added a fancy version number in the top left.
Added more random “No” responses for false force checks.
Added a timer that tells you when the next automatic scan is.
Moved the custom folder to _internal for better compile bundling. Replace files inside with the same names and enjoy (GIF support coming soon).
Cleaned up a LOT spaghetti code.
Debug mode (F1) now logs scans better and outputs structured mission data: Mission Type|SP/N|Void Tier|Expiry Time (planning to add node logging soon).
Trimmed down the alarm sound so it’s more sudden and scary.
Added a super secret debug button, lots of information for me... effectively a noise button for everyone else (do not believe its lies).
Created better code flow and improved the core logic.
OVERHAULED the popup system pipelines and lifecycle, cleaned up behavior, added dynamic expiry tracking for popups, improved popup handling/state management.
Fixed an issue where the popup could incorrectly appear at startup or duplicate/desync from API states.
Reworked timers to be more self-scheduling so the UI no longer depends directly on external loop timing.
Attached expiry times more directly to scan cycles to better handle desync situations.
Reworked scan scheduling loops to be more event aware instead of relying on fixed polling.