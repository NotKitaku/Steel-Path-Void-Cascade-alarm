# Steel-Path-Void-Cascade-alarm 0.1.0
Tracks Steel Path Void Cascade omnia fissures in Warframe. Automatically checks every 5 minutes, with a manual force check option.

To install, open the EXE, allow it to make changes, choose where you want it and whether you want a desktop shortcut and enjoy. (i will include the zip files in another branch at some point)

Press F1 to open a debug console showing all active Void Fissures, including mission type, Steel Path/Normal status, aand relic tier.

(this isnt malware, Windows flags the app because it’s an unsigned PyInstaller executable from an "unknown publisher" (me). It also continuously checks an online API in the background, uses threaded loops, and plays alerts.)
